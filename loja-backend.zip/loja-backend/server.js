require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const produtosRouter = require('./src/routes/produtos');

const app = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/loja-salgadinhos';

// Middlewares
app.use(cors());
app.use(express.json());

// Rotas
app.use('/api/produtos', produtosRouter);

// Rota raiz de teste
app.get('/', (req, res) => {
  res.json({ mensagem: 'API da Loja de Salgadinhos funcionando!' });
});

// Conexão com MongoDB e start do servidor
mongoose
  .connect(MONGO_URI) 
  .then(() => {
    console.log('✅ Conectado ao MongoDB');
    app.listen(PORT, () => {
      console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('❌ Erro ao conectar no MongoDB:', err.message);
    process.exit(1);
  });

  console.log('URI sendo usada:', MONGO_URI);