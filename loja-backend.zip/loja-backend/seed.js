require('dotenv').config();
const mongoose = require('mongoose');
const Produto = require('./src/models/Produto');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/loja-salgadinhos';

const produtos = [
  {
    nome: 'Dorito Nacho',
    preco: 8.99,
    imagem: 'https://destro.fbitsstatic.net/img/p/salgadinho-doritos-queijo-nacho-140g-80349/266904.jpg?w=500&h=500&v=202501231555&qs=ignore',
    fabricante: 'Elma Chips',
    descricao: 'Salgadinho triangular sabor queijo nacho',
    especificacoes: 'Peso: 210g | Validade: 20/11/2032 | Ingredientes: Milho, óleo vegetal, queijo em pó, sal',
  },
  {
    nome: 'Chettos Lua',
    preco: 6.50,
    imagem: 'https://drogal.vtexassets.com/arquivos/ids/195782/60179.jpg?v=638394763999700000',
    fabricante: 'Elma Chips',
    descricao: 'Salgadinho em formato de lua, sabor queijo',
    especificacoes: 'Peso: 160g | Validade: 15/05/2030 | Ingredientes: Milho, queijo em pó, óleo vegetal',
  },
  {
    nome: 'Ruffles Cebola e Salsa',
    preco: 9.99,
    imagem: 'https://prezunic.vtexassets.com/arquivos/ids/190452-800-auto?v=638368834290700000&width=800&height=auto&aspect=true',
    fabricante: 'Elma Chips',
    descricao: 'Batata frita ondulada sabor cebola e salsa',
    especificacoes: 'Peso: 160g | Validade: 06/10/2029 | Ingredientes: Batata, óleo vegetal, tempero',
  },
  {
    nome: 'Fandangos Presunto',
    preco: 5.99,
    imagem: 'https://redemix.vteximg.com.br/arquivos/ids/217434-1000-1000/7892840822859.jpg?v=638499994537500000',
    fabricante: 'Elma Chips',
    descricao: 'Salgadinho de milho sabor presunto',
    especificacoes: 'Peso: 130g | Validade: 11/06/2100 | Ingredientes: Milho, óleo vegetal, sabor presunto',
  },
  {
    nome: 'Torcida Bacon',
    preco: 4.99,
    imagem: 'https://static1.efacil.com.br/wcsstore/ExtendedSitesCatalogAssetStore/Imagens/1000/4901019_01.jpg',
    fabricante: 'Lucky',
    descricao: 'Salgadinho de trigo sabor bacon',
    especificacoes: 'Peso: 100g | Validade: 01/12/2040 | Ingredientes: Trigo, óleo vegetal, tempero bacon',
  },
  {
    nome: 'Pringles Original',
    preco: 12.99,
    imagem: 'https://mercantilnovaera.vtexassets.com/arquivos/ids/218267/Batata-Chips-Pringles-Sabor-Original-Pote-104g.jpg?v=638593284493500000',
    fabricante: 'Kelloggs',
    descricao: 'Batata chips empilhável sabor original',
    especificacoes: 'Peso: 120g | Validade: 10/03/2036 | Ingredientes: Batata desidratada, óleo, sal',
  },
];

async function seed() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ Conectado ao MongoDB');

    await Produto.deleteMany({});
    console.log('🗑️  Coleção limpa');

    await Produto.insertMany(produtos);
    console.log(`🌱 ${produtos.length} produtos inseridos com sucesso!`);
  } catch (error) {
    console.error('❌ Erro no seed:', error.message);
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Desconectado do MongoDB');
  }
}

seed();
