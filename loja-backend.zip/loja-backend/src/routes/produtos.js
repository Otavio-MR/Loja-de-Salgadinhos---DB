const express = require('express');
const router = express.Router();
const Produto = require('../models/Produto');

// GET /api/produtos - listar todos
router.get('/', async (req, res) => {
  try {
    const produtos = await Produto.find();
    res.json(produtos);
  } catch (error) {
    res.status(500).json({ mensagem: 'Erro ao buscar produtos', erro: error.message });
  }
});

// GET /api/produtos/:id - buscar por ID
router.get('/:id', async (req, res) => {
  try {
    const produto = await Produto.findById(req.params.id);
    if (!produto) {
      return res.status(404).json({ mensagem: 'Produto não encontrado' });
    }
    res.json(produto);
  } catch (error) {
    res.status(500).json({ mensagem: 'Erro ao buscar produto', erro: error.message });
  }
});

// POST /api/produtos - criar produto
router.post('/', async (req, res) => {
  try {
    const produto = new Produto(req.body);
    const salvo = await produto.save();
    res.status(201).json(salvo);
  } catch (error) {
    res.status(400).json({ mensagem: 'Erro ao criar produto', erro: error.message });
  }
});

// PUT /api/produtos/:id - atualizar produto
router.put('/:id', async (req, res) => {
  try {
    const produto = await Produto.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!produto) {
      return res.status(404).json({ mensagem: 'Produto não encontrado' });
    }
    res.json(produto);
  } catch (error) {
    res.status(400).json({ mensagem: 'Erro ao atualizar produto', erro: error.message });
  }
});

// DELETE /api/produtos/:id - deletar produto
router.delete('/:id', async (req, res) => {
  try {
    const produto = await Produto.findByIdAndDelete(req.params.id);
    if (!produto) {
      return res.status(404).json({ mensagem: 'Produto não encontrado' });
    }
    res.json({ mensagem: 'Produto deletado com sucesso' });
  } catch (error) {
    res.status(500).json({ mensagem: 'Erro ao deletar produto', erro: error.message });
  }
});

module.exports = router;
